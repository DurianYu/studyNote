'use client'

import { useEffect, useRef, useState, useCallback } from 'react'

// Game constants
const GAME_WIDTH = 480
const GAME_HEIGHT = 720
const GRAVITY = 0.5
const JUMP_FORCE = -16
const MOVE_SPEED = 6
const PLATFORM_HEIGHT = 15
const PLATFORM_MIN_WIDTH = 70
const PLATFORM_MAX_WIDTH = 150
const PLAYER_WIDTH = 40
const PLAYER_HEIGHT = 60
const MAX_LAYERS = 1000
const LAYER_HEIGHT = 130

// Platform types
const PLATFORM_NORMAL = 'normal'
const PLATFORM_WET = 'wet'
const PLATFORM_SNOW = 'snow'

// Item types
const ITEM_ROCKET = 'rocket'
const ITEM_STAR = 'star'
const ITEM_MUSHROOM = 'mushroom'

// Sound effect types
const SOUND_FART = 'fart'
const SOUND_LIGHTNING = 'lightning'
const SOUND_LAUGH = 'laugh'
const SOUND_BOING = 'boing'
const SOUND_POP = 'pop'

// Background themes (each theme covers 200 layers)
const THEMES = ['sky', 'atmosphere', 'space', 'moon', 'solar']
const LAYERS_PER_THEME = 200

interface Platform {
  x: number
  y: number  // World Y coordinate (lower = higher in world)
  width: number
  type: string
  layer: number
}

interface Item {
  x: number
  y: number
  type: string
  collected: boolean
  layer: number
}

interface Player {
  x: number
  y: number  // World Y coordinate
  vx: number
  vy: number
  width: number
  height: number
  rocketActive: boolean
  rocketTime: number
  starActive: boolean
  starTime: number
  mushroomActive: boolean
  mushroomTime: number
  facingRight: boolean
}

interface RippleEffect {
  x: number
  y: number
  radius: number
  alpha: number
}

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  life: number
  color: string
  size: number
}

// Helper functions (defined outside component to avoid hoisting issues)
const drawCloud = (ctx: CanvasRenderingContext2D, x: number, y: number) => {
  ctx.fillStyle = 'rgba(255, 255, 255, 0.9)'
  ctx.beginPath()
  ctx.arc(x, y, 25, 0, Math.PI * 2)
  ctx.arc(x + 25, y - 10, 30, 0, Math.PI * 2)
  ctx.arc(x + 50, y, 25, 0, Math.PI * 2)
  ctx.arc(x + 25, y + 10, 20, 0, Math.PI * 2)
  ctx.fill()
}

export default function Game() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const gameStateRef = useRef({
    player: null as Player | null,
    platforms: [] as Platform[],
    items: [] as Item[],
    cameraY: 0,  // Camera offset (how much we've scrolled up)
    currentLayer: 0,
    highestLayer: 0,
    gameOver: false,
    gameWon: false,
    gameStarted: false,
    ripples: [] as RippleEffect[],
    particles: [] as Particle[],
    keys: {} as Record<string, boolean>,
    audioContext: null as AudioContext | null,
    bgmGain: null as GainNode | null,
    audioDelay: 0.05,
    frameCount: 0,
    lastTime: 0,
    deltaTime: 0,
    powerUpText: null as { text: string; timer: number } | null,
    generatedLayers: new Set<number>()
  })
  const [gameState, setGameState] = useState({
    started: false,
    gameOver: false,
    gameWon: false,
    layer: 0
  })
  const animationRef = useRef<number>(0)

  // Initialize audio context
  const initAudio = useCallback(() => {
    const state = gameStateRef.current
    if (!state.audioContext) {
      state.audioContext = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)()
    }
    return state.audioContext
  }, [])

  // Play sound effects
  const playSound = useCallback((type: string) => {
    const ctx = initAudio()
    if (!ctx) return

    const state = gameStateRef.current
    const now = ctx.currentTime + state.audioDelay

    if (type === SOUND_FART) {
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      const filter = ctx.createBiquadFilter()
      
      osc.type = 'sawtooth'
      osc.frequency.setValueAtTime(80, now)
      osc.frequency.linearRampToValueAtTime(40, now + 0.3)
      
      filter.type = 'lowpass'
      filter.frequency.value = 300
      
      gain.gain.setValueAtTime(0.4, now)
      gain.gain.linearRampToValueAtTime(0, now + 0.3)
      
      osc.connect(filter)
      filter.connect(gain)
      gain.connect(ctx.destination)
      
      osc.start(now)
      osc.stop(now + 0.3)
    } else if (type === SOUND_LIGHTNING) {
      const noise = ctx.createOscillator()
      const gain = ctx.createGain()
      
      noise.type = 'sawtooth'
      noise.frequency.setValueAtTime(1000, now)
      noise.frequency.linearRampToValueAtTime(100, now + 0.1)
      noise.frequency.linearRampToValueAtTime(2000, now + 0.2)
      
      gain.gain.setValueAtTime(0.3, now)
      gain.gain.linearRampToValueAtTime(0, now + 0.2)
      
      noise.connect(gain)
      gain.connect(ctx.destination)
      
      noise.start(now)
      noise.stop(now + 0.2)
    } else if (type === SOUND_LAUGH) {
      const frequencies = [400, 450, 400, 450, 400, 350]
      let t = now
      frequencies.forEach(freq => {
        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        
        osc.type = 'sine'
        osc.frequency.value = freq
        
        gain.gain.setValueAtTime(0.2, t)
        gain.gain.linearRampToValueAtTime(0, t + 0.08)
        
        osc.connect(gain)
        gain.connect(ctx.destination)
        
        osc.start(t)
        osc.stop(t + 0.08)
        t += 0.08
      })
    } else if (type === SOUND_BOING) {
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      
      osc.type = 'sine'
      osc.frequency.setValueAtTime(200, now)
      osc.frequency.exponentialRampToValueAtTime(600, now + 0.1)
      osc.frequency.exponentialRampToValueAtTime(300, now + 0.2)
      
      gain.gain.setValueAtTime(0.3, now)
      gain.gain.linearRampToValueAtTime(0, now + 0.2)
      
      osc.connect(gain)
      gain.connect(ctx.destination)
      
      osc.start(now)
      osc.stop(now + 0.2)
    } else if (type === SOUND_POP) {
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      
      osc.type = 'sine'
      osc.frequency.setValueAtTime(800, now)
      osc.frequency.exponentialRampToValueAtTime(200, now + 0.1)
      
      gain.gain.setValueAtTime(0.3, now)
      gain.gain.linearRampToValueAtTime(0, now + 0.1)
      
      osc.connect(gain)
      gain.connect(ctx.destination)
      
      osc.start(now)
      osc.stop(now + 0.1)
    }
  }, [initAudio])

  // Generate background music using Web Audio API
  const startBGM = useCallback(() => {
    const ctx = initAudio()
    if (!ctx) return

    const state = gameStateRef.current

    // Create a happy electronic synth melody
    const masterGain = ctx.createGain()
    masterGain.gain.value = 0.12
    masterGain.connect(ctx.destination)
    state.bgmGain = masterGain

    // Melody notes (happy tune)
    const melodyNotes = [
      { freq: 523.25, duration: 0.2 }, // C5
      { freq: 587.33, duration: 0.2 }, // D5
      { freq: 659.25, duration: 0.2 }, // E5
      { freq: 783.99, duration: 0.4 }, // G5
      { freq: 659.25, duration: 0.2 }, // E5
      { freq: 783.99, duration: 0.4 }, // G5
      { freq: 880.00, duration: 0.2 }, // A5
      { freq: 783.99, duration: 0.2 }, // G5
      { freq: 659.25, duration: 0.2 }, // E5
      { freq: 587.33, duration: 0.4 }, // D5
      { freq: 523.25, duration: 0.6 }, // C5
    ]

    const loopDuration = melodyNotes.reduce((sum, n) => sum + n.duration, 0)

    const playMelody = () => {
      if (!state.gameStarted || state.gameOver || state.gameWon) return

      let time = ctx.currentTime + state.audioDelay
      melodyNotes.forEach((note) => {
        const osc = ctx.createOscillator()
        const noteGain = ctx.createGain()
        
        osc.type = 'square'
        osc.frequency.value = note.freq
        
        noteGain.gain.setValueAtTime(0, time)
        noteGain.gain.linearRampToValueAtTime(0.3, time + 0.02)
        noteGain.gain.linearRampToValueAtTime(0.1, time + note.duration * 0.8)
        noteGain.gain.linearRampToValueAtTime(0, time + note.duration)
        
        osc.connect(noteGain)
        noteGain.connect(masterGain)
        
        osc.start(time)
        osc.stop(time + note.duration)
        
        time += note.duration
      })

      // Schedule next loop
      setTimeout(playMelody, loopDuration * 1000)
    }

    // Add bass line
    const bassNotes = [261.63, 196.00, 220.00, 261.63] // C4, G3, A3, C4
    const playBass = () => {
      if (!state.gameStarted || state.gameOver || state.gameWon) return

      let time = ctx.currentTime + state.audioDelay
      bassNotes.forEach(freq => {
        const osc = ctx.createOscillator()
        const noteGain = ctx.createGain()
        
        osc.type = 'triangle'
        osc.frequency.value = freq
        
        noteGain.gain.setValueAtTime(0.2, time)
        noteGain.gain.linearRampToValueAtTime(0.1, time + 0.4)
        noteGain.gain.linearRampToValueAtTime(0, time + 0.5)
        
        osc.connect(noteGain)
        noteGain.connect(masterGain)
        
        osc.start(time)
        osc.stop(time + 0.5)
        
        time += 0.5
      })

      setTimeout(playBass, 2000)
    }

    playMelody()
    playBass()
  }, [initAudio])

  // Create ripple effect
  const createRipple = useCallback((x: number, y: number) => {
    const state = gameStateRef.current
    for (let i = 0; i < 3; i++) {
      state.ripples.push({
        x,
        y,
        radius: 10 + i * 10,
        alpha: 1 - i * 0.2
      })
    }
  }, [])

  // Create particles
  const createParticles = useCallback((x: number, y: number, color: string, count: number) => {
    const state = gameStateRef.current
    for (let i = 0; i < count; i++) {
      state.particles.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 8,
        vy: (Math.random() - 0.5) * 8 - 2,
        life: 1,
        color,
        size: Math.random() * 4 + 2
      })
    }
  }, [])

  // Generate platform at layer - ONE platform per layer, fixed world position
  const generatePlatform = useCallback((layer: number) => {
    const state = gameStateRef.current
    
    // Skip if already generated
    if (state.generatedLayers.has(layer)) return
    state.generatedLayers.add(layer)
    
    const difficulty = Math.min(layer / MAX_LAYERS, 1)
    
    // Platform width decreases with difficulty
    const width = PLATFORM_MAX_WIDTH - (PLATFORM_MAX_WIDTH - PLATFORM_MIN_WIDTH) * difficulty * 0.6
    const actualWidth = width + Math.random() * 30
    
    // Random horizontal position
    const x = Math.random() * (GAME_WIDTH - actualWidth)
    
    // Fixed world Y coordinate (layer 0 at bottom, higher layers have lower Y values)
    const y = -layer * LAYER_HEIGHT
    
    // Platform type based on layer and randomness
    let type = PLATFORM_NORMAL
    const rand = Math.random()
    if (layer > 100 && rand < 0.4) {
      type = PLATFORM_WET
    } else if (layer > 50 && rand < 0.55) {
      type = PLATFORM_SNOW
    }
    
    state.platforms.push({
      x,
      y,
      width: actualWidth,
      type,
      layer
    })
    
    // Generate items with lower probability - rocket is much rarer
    if (Math.random() < 0.06) {
      const itemRand = Math.random()
      let itemType = ITEM_MUSHROOM
      if (itemRand < 0.1) {
        itemType = ITEM_ROCKET
      } else if (itemRand < 0.4) {
        itemType = ITEM_STAR
      }
      
      state.items.push({
        x: x + actualWidth / 2 - 15,
        y: y - 40,
        type: itemType,
        collected: false,
        layer
      })
    }
  }, [])

  // Draw background
  const drawBackground = useCallback((ctx: CanvasRenderingContext2D) => {
    const state = gameStateRef.current
    const layer = state.currentLayer
    let themeIndex = Math.floor(layer / LAYERS_PER_THEME)
    themeIndex = Math.min(themeIndex, THEMES.length - 1)
    const theme = THEMES[themeIndex]
    
    // Create gradient background
    const gradient = ctx.createLinearGradient(0, 0, 0, GAME_HEIGHT)
    
    switch (theme) {
      case 'sky':
        gradient.addColorStop(0, '#87CEEB')
        gradient.addColorStop(0.5, '#B0E0E6')
        gradient.addColorStop(1, '#E0F6FF')
        break
      case 'atmosphere':
        gradient.addColorStop(0, '#4A90D9')
        gradient.addColorStop(0.5, '#1E5AA8')
        gradient.addColorStop(1, '#0A2E5C')
        break
      case 'space':
        gradient.addColorStop(0, '#0A0A20')
        gradient.addColorStop(0.5, '#0F0F30')
        gradient.addColorStop(1, '#1A1A40')
        break
      case 'moon':
        gradient.addColorStop(0, '#2A2A3A')
        gradient.addColorStop(0.5, '#3A3A4A')
        gradient.addColorStop(1, '#4A4A5A')
        break
      case 'solar':
        gradient.addColorStop(0, '#1A0A20')
        gradient.addColorStop(0.5, '#2A1030')
        gradient.addColorStop(1, '#3A1A40')
        break
    }
    
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT)
    
    // Draw theme-specific elements
    if (theme === 'sky') {
      drawCloud(ctx, 50, 100)
      drawCloud(ctx, 200, 200)
      drawCloud(ctx, 350, 150)
      drawCloud(ctx, 100, 400)
      drawCloud(ctx, 300, 500)
    } else if (theme === 'atmosphere') {
      const glowGradient = ctx.createRadialGradient(GAME_WIDTH / 2, GAME_HEIGHT + 100, 0, GAME_WIDTH / 2, GAME_HEIGHT + 100, 400)
      glowGradient.addColorStop(0, 'rgba(255, 200, 100, 0.3)')
      glowGradient.addColorStop(1, 'rgba(255, 200, 100, 0)')
      ctx.fillStyle = glowGradient
      ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT)
    } else if (theme === 'space' || theme === 'moon' || theme === 'solar') {
      const starSeed = 12345
      for (let i = 0; i < 50; i++) {
        const sx = ((starSeed * (i + 1) * 7) % GAME_WIDTH)
        const sy = ((starSeed * (i + 1) * 13) % GAME_HEIGHT)
        const twinkle = Math.sin(state.frameCount * 0.05 + i) * 0.3 + 0.7
        
        ctx.beginPath()
        ctx.arc(sx, sy, 1.5 * twinkle, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(255, 255, 255, ${twinkle})`
        ctx.fill()
      }
      
      if (theme === 'moon') {
        ctx.beginPath()
        ctx.arc(GAME_WIDTH - 80, 100, 50, 0, Math.PI * 2)
        ctx.fillStyle = '#DDD'
        ctx.fill()
        ctx.beginPath()
        ctx.arc(GAME_WIDTH - 95, 85, 10, 0, Math.PI * 2)
        ctx.fillStyle = '#BBB'
        ctx.fill()
        ctx.beginPath()
        ctx.arc(GAME_WIDTH - 70, 110, 8, 0, Math.PI * 2)
        ctx.fillStyle = '#BBB'
        ctx.fill()
      }
      
      if (theme === 'solar') {
        const sunGradient = ctx.createRadialGradient(80, 120, 0, 80, 120, 60)
        sunGradient.addColorStop(0, '#FFD700')
        sunGradient.addColorStop(0.5, '#FFA500')
        sunGradient.addColorStop(1, 'rgba(255, 165, 0, 0)')
        ctx.fillStyle = sunGradient
        ctx.beginPath()
        ctx.arc(80, 120, 60, 0, Math.PI * 2)
        ctx.fill()
        
        ctx.beginPath()
        ctx.arc(GAME_WIDTH - 100, 80, 20, 0, Math.PI * 2)
        ctx.fillStyle = '#E74C3C'
        ctx.fill()
        
        ctx.beginPath()
        ctx.arc(GAME_WIDTH - 60, 180, 30, 0, Math.PI * 2)
        ctx.fillStyle = '#F39C12'
        ctx.fill()
        
        ctx.beginPath()
        ctx.ellipse(GAME_WIDTH - 60, 180, 50, 15, 0.3, 0, Math.PI * 2)
        ctx.strokeStyle = 'rgba(243, 156, 18, 0.5)'
        ctx.lineWidth = 3
        ctx.stroke()
      }
    }
  }, [])

  // Draw platform (convert world Y to screen Y)
  const drawPlatform = useCallback((ctx: CanvasRenderingContext2D, platform: Platform, cameraY: number) => {
    const drawY = platform.y + cameraY
    
    // Skip if not visible
    if (drawY < -PLATFORM_HEIGHT || drawY > GAME_HEIGHT + PLATFORM_HEIGHT) return
    
    ctx.fillStyle = platform.type === PLATFORM_WET ? '#4A90A4' : platform.type === PLATFORM_SNOW ? '#E8E8F0' : '#7CB342'
    ctx.fillRect(platform.x, drawY, platform.width, PLATFORM_HEIGHT)
    
    ctx.fillStyle = platform.type === PLATFORM_WET ? '#2E6073' : platform.type === PLATFORM_SNOW ? '#FFFFFF' : '#558B2F'
    ctx.fillRect(platform.x, drawY, platform.width, 5)
    
    if (platform.type === PLATFORM_NORMAL) {
      ctx.strokeStyle = '#7CB342'
      ctx.lineWidth = 2
      for (let i = 0; i < platform.width; i += 15) {
        const bladeHeight = 8 + Math.random() * 5
        ctx.beginPath()
        ctx.moveTo(platform.x + i, drawY)
        ctx.lineTo(platform.x + i + 3, drawY - bladeHeight)
        ctx.stroke()
      }
    } else if (platform.type === PLATFORM_WET) {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)'
      ctx.lineWidth = 1
      for (let i = 0; i < platform.width; i += 20) {
        ctx.beginPath()
        ctx.arc(platform.x + i + 10, drawY + 7, 5, 0, Math.PI)
        ctx.stroke()
      }
    } else if (platform.type === PLATFORM_SNOW) {
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)'
      for (let i = 0; i < platform.width; i += 25) {
        ctx.beginPath()
        ctx.arc(platform.x + i + Math.random() * 20, drawY + Math.random() * PLATFORM_HEIGHT, 2, 0, Math.PI * 2)
        ctx.fill()
      }
    }
  }, [])

  // Draw item
  const drawItem = useCallback((ctx: CanvasRenderingContext2D, item: Item, cameraY: number, frameCount: number) => {
    if (item.collected) return
    
    const drawY = item.y + cameraY
    
    // Skip if not visible
    if (drawY < -50 || drawY > GAME_HEIGHT + 50) return
    
    const bob = Math.sin(Date.now() * 0.005) * 3
    
    ctx.save()
    ctx.translate(item.x + 15, drawY + bob + 15)
    
    if (item.type === ITEM_ROCKET) {
      ctx.fillStyle = '#E74C3C'
      ctx.beginPath()
      ctx.moveTo(0, -15)
      ctx.lineTo(8, 10)
      ctx.lineTo(-8, 10)
      ctx.closePath()
      ctx.fill()
      
      ctx.fillStyle = '#F39C12'
      ctx.beginPath()
      ctx.moveTo(-5, 10)
      ctx.lineTo(5, 10)
      ctx.lineTo(0, 20 + Math.sin(frameCount * 0.02) * 3)
      ctx.closePath()
      ctx.fill()
      
      ctx.fillStyle = '#3498DB'
      ctx.beginPath()
      ctx.arc(0, -2, 4, 0, Math.PI * 2)
      ctx.fill()
      
    } else if (item.type === ITEM_STAR) {
      ctx.fillStyle = '#FFD700'
      ctx.beginPath()
      for (let i = 0; i < 5; i++) {
        const angle = (i * 4 * Math.PI) / 5 - Math.PI / 2
        const px = Math.cos(angle) * 12
        const py = Math.sin(angle) * 12
        if (i === 0) ctx.moveTo(px, py)
        else ctx.lineTo(px, py)
      }
      ctx.closePath()
      ctx.fill()
      
      ctx.shadowColor = '#FFD700'
      ctx.shadowBlur = 10
      ctx.fill()
      ctx.shadowBlur = 0
      
    } else if (item.type === ITEM_MUSHROOM) {
      ctx.fillStyle = '#E74C3C'
      ctx.beginPath()
      ctx.arc(0, -5, 12, Math.PI, 0)
      ctx.fill()
      
      ctx.fillStyle = '#FFF'
      ctx.beginPath()
      ctx.arc(-5, -10, 3, 0, Math.PI * 2)
      ctx.arc(4, -8, 2, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.fillStyle = '#F5DEB3'
      ctx.fillRect(-5, -5, 10, 12)
    }
    
    ctx.restore()
  }, [])

  // Draw player (convert world Y to screen Y)
  const drawPlayer = useCallback((ctx: CanvasRenderingContext2D, player: Player, cameraY: number, frameCount: number) => {
    const drawY = player.y + cameraY
    const scale = player.mushroomActive ? 1.5 : 1
    
    ctx.save()
    ctx.translate(player.x + player.width / 2, drawY + player.height / 2)
    ctx.scale(scale, scale)
    if (!player.facingRight) ctx.scale(-1, 1)
    ctx.translate(-player.width / 2, -player.height / 2)
    
    if (player.starActive) {
      ctx.shadowColor = '#FFD700'
      ctx.shadowBlur = 20
    }
    
    if (player.rocketActive) {
      ctx.fillStyle = '#F39C12'
      for (let i = 0; i < 3; i++) {
        const flameHeight = 15 + Math.sin(frameCount * 0.3 + i) * 5
        ctx.beginPath()
        ctx.moveTo(player.width / 2 - 8 + i * 8, player.height)
        ctx.lineTo(player.width / 2 - 4 + i * 8, player.height + flameHeight)
        ctx.lineTo(player.width / 2 + i * 8, player.height)
        ctx.fill()
      }
    }
    
    // Body
    ctx.fillStyle = '#FFDAB9'
    ctx.fillRect(12, 20, 16, 25)
    
    // Head
    ctx.fillStyle = '#FFDAB9'
    ctx.beginPath()
    ctx.arc(20, 12, 12, 0, Math.PI * 2)
    ctx.fill()
    
    // Hair
    ctx.fillStyle = '#2C2C2C'
    ctx.beginPath()
    ctx.arc(20, 8, 10, Math.PI, 0)
    ctx.fill()
    ctx.fillRect(10, 8, 20, 5)
    
    // Eyes
    ctx.fillStyle = '#000'
    ctx.beginPath()
    ctx.arc(16, 12, 2, 0, Math.PI * 2)
    ctx.arc(24, 12, 2, 0, Math.PI * 2)
    ctx.fill()
    
    // Blush
    ctx.fillStyle = '#FFB6C1'
    ctx.beginPath()
    ctx.ellipse(13, 16, 3, 2, 0, 0, Math.PI * 2)
    ctx.ellipse(27, 16, 3, 2, 0, 0, Math.PI * 2)
    ctx.fill()
    
    // Mouth
    ctx.strokeStyle = '#000'
    ctx.lineWidth = 1
    ctx.beginPath()
    ctx.arc(20, 18, 3, 0, Math.PI)
    ctx.stroke()
    
    // Shirt
    ctx.fillStyle = '#4169E1'
    ctx.fillRect(10, 22, 20, 15)
    
    // Arms
    ctx.fillStyle = '#FFDAB9'
    ctx.fillRect(5, 24, 8, 4)
    ctx.fillRect(27, 24, 8, 4)
    
    // Legs
    ctx.fillStyle = '#4A4A4A'
    ctx.fillRect(13, 40, 5, 15)
    ctx.fillRect(22, 40, 5, 15)
    
    // Shoes
    ctx.fillStyle = '#8B4513'
    ctx.fillRect(11, 52, 8, 5)
    ctx.fillRect(21, 52, 8, 5)
    
    ctx.restore()
  }, [])

  // Draw ripples
  const drawRipples = useCallback((ctx: CanvasRenderingContext2D, cameraY: number) => {
    const state = gameStateRef.current
    
    state.ripples.forEach((ripple, index) => {
      const drawY = ripple.y + cameraY
      
      ctx.beginPath()
      ctx.arc(ripple.x, drawY, ripple.radius, 0, Math.PI * 2)
      ctx.strokeStyle = `rgba(255, 215, 0, ${ripple.alpha})`
      ctx.lineWidth = 3
      ctx.stroke()
      
      ripple.radius += 3
      ripple.alpha -= 0.03
      
      if (ripple.alpha <= 0) {
        state.ripples.splice(index, 1)
      }
    })
  }, [])

  // Draw particles
  const drawParticles = useCallback((ctx: CanvasRenderingContext2D, cameraY: number) => {
    const state = gameStateRef.current
    
    state.particles.forEach((particle, index) => {
      const drawY = particle.y + cameraY
      
      ctx.beginPath()
      ctx.arc(particle.x, drawY, particle.size * particle.life, 0, Math.PI * 2)
      ctx.fillStyle = particle.color.replace(')', `, ${particle.life})`).replace('rgb', 'rgba')
      ctx.fill()
      
      particle.x += particle.vx
      particle.y += particle.vy
      particle.vy += 0.2
      particle.life -= 0.02
      
      if (particle.life <= 0) {
        state.particles.splice(index, 1)
      }
    })
  }, [])

  // Draw HUD with power-up text
  const drawHUD = useCallback((ctx: CanvasRenderingContext2D, layer: number) => {
    const state = gameStateRef.current
    
    // Layer counter
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)'
    ctx.fillRect(GAME_WIDTH - 120, 10, 110, 50)
    
    ctx.fillStyle = '#FFD700'
    ctx.font = 'bold 14px Arial'
    ctx.textAlign = 'right'
    ctx.fillText('层数', GAME_WIDTH - 15, 32)
    
    ctx.fillStyle = '#FFF'
    ctx.font = 'bold 28px Arial'
    ctx.fillText(`${layer}`, GAME_WIDTH - 15, 58)
    
    // Progress bar
    const progress = Math.min(layer / MAX_LAYERS, 1)
    ctx.fillStyle = 'rgba(0, 0, 0, 0.3)'
    ctx.fillRect(10, 10, 150, 10)
    ctx.fillStyle = '#4CAF50'
    ctx.fillRect(10, 10, 150 * progress, 10)
    
    ctx.fillStyle = '#FFF'
    ctx.font = '10px Arial'
    ctx.textAlign = 'left'
    ctx.fillText(`${Math.round(progress * 100)}%`, 165, 18)
    
    // Draw power-up text with rainbow effect
    if (state.powerUpText) {
      const textProgress = 1 - (state.powerUpText.timer / 120)
      const alpha = 1 - textProgress * 0.5
      const yOffset = textProgress * 50
      
      // Rainbow colors cycling
      const hue = (state.frameCount * 5) % 360
      const colors = [
        `hsl(${hue}, 100%, 50%)`,
        `hsl(${(hue + 60) % 360}, 100%, 50%)`,
        `hsl(${(hue + 120) % 360}, 100%, 50%)`,
        `hsl(${(hue + 180) % 360}, 100%, 50%)`,
        `hsl(${(hue + 240) % 360}, 100%, 50%)`,
      ]
      
      ctx.save()
      ctx.textAlign = 'center'
      ctx.font = `bold ${36 + Math.sin(state.frameCount * 0.2) * 4}px Arial`
      
      ctx.shadowColor = colors[Math.floor(state.frameCount / 5) % colors.length]
      ctx.shadowBlur = 30 + Math.sin(state.frameCount * 0.15) * 10
      
      const text = state.powerUpText.text
      const x = GAME_WIDTH / 2
      const y = 150 - yOffset
      
      const gradient = ctx.createLinearGradient(x - 100, y, x + 100, y)
      colors.forEach((color, i) => {
        gradient.addColorStop(i / (colors.length - 1), color)
      })
      
      ctx.fillStyle = gradient
      ctx.globalAlpha = alpha
      ctx.strokeStyle = '#000'
      ctx.lineWidth = 3
      ctx.strokeText(text, x, y)
      ctx.fillText(text, x, y)
      
      ctx.restore()
    }
  }, [])

  // Draw start screen
  const drawStartScreen = useCallback((ctx: CanvasRenderingContext2D) => {
    const gradient = ctx.createLinearGradient(0, 0, 0, GAME_HEIGHT)
    gradient.addColorStop(0, '#1a1a2e')
    gradient.addColorStop(1, '#16213e')
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT)
    
    ctx.fillStyle = '#FFD700'
    ctx.font = 'bold 36px Arial'
    ctx.textAlign = 'center'
    ctx.shadowColor = '#FF6B6B'
    ctx.shadowBlur = 20
    ctx.fillText('杜青林', GAME_WIDTH / 2, 200)
    ctx.fillText('大冒险', GAME_WIDTH / 2, 260)
    ctx.shadowBlur = 0
    
    ctx.fillStyle = '#FFF'
    ctx.font = '16px Arial'
    ctx.fillText('向上跳跳乐', GAME_WIDTH / 2, 320)
    
    const flash = Math.sin(Date.now() * 0.005) > 0
    if (flash) {
      ctx.fillStyle = '#FFD700'
      ctx.font = 'bold 20px Arial'
      ctx.fillText('INSERT COIN / START', GAME_WIDTH / 2, 450)
    }
    
    ctx.fillStyle = '#AAA'
    ctx.font = '14px Arial'
    ctx.fillText('A/D 或 方向键 移动', GAME_WIDTH / 2, 550)
    ctx.fillText('点击屏幕或按任意键开始', GAME_WIDTH / 2, 580)
    
    ctx.fillStyle = '#FFDAB9'
    ctx.fillRect(GAME_WIDTH / 2 - 20, 100, 40, 50)
    ctx.beginPath()
    ctx.arc(GAME_WIDTH / 2, 90, 20, 0, Math.PI * 2)
    ctx.fill()
  }, [])

  // Draw game over screen
  const drawGameOverScreen = useCallback((ctx: CanvasRenderingContext2D) => {
    const state = gameStateRef.current
    
    ctx.fillStyle = 'rgba(0, 0, 0, 0.8)'
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT)
    
    ctx.fillStyle = '#8B0000'
    ctx.font = 'bold 48px Arial'
    ctx.textAlign = 'center'
    ctx.shadowColor = '#FF0000'
    ctx.shadowBlur = 30
    ctx.fillText('You are dead', GAME_WIDTH / 2, GAME_HEIGHT / 2 - 50)
    ctx.shadowBlur = 0
    
    ctx.fillStyle = '#FFF'
    ctx.font = '24px Arial'
    ctx.fillText(`到达层数: ${state.highestLayer}`, GAME_WIDTH / 2, GAME_HEIGHT / 2 + 20)
    
    const btnY = GAME_HEIGHT / 2 + 80
    ctx.fillStyle = '#E74C3C'
    ctx.fillRect(GAME_WIDTH / 2 - 60, btnY, 120, 40)
    ctx.fillStyle = '#FFF'
    ctx.font = 'bold 18px Arial'
    ctx.fillText('重试', GAME_WIDTH / 2, btnY + 28)
  }, [])

  // Draw win screen
  const drawWinScreen = useCallback((ctx: CanvasRenderingContext2D) => {
    const gradient = ctx.createLinearGradient(0, 0, 0, GAME_HEIGHT)
    gradient.addColorStop(0, '#FFD700')
    gradient.addColorStop(1, '#FFA500')
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT)
    
    ctx.fillStyle = '#8B4513'
    ctx.font = 'bold 48px Arial'
    ctx.textAlign = 'center'
    ctx.shadowColor = '#FFF'
    ctx.shadowBlur = 20
    ctx.fillText('🎉 恭喜通关! 🎉', GAME_WIDTH / 2, GAME_HEIGHT / 2 - 50)
    ctx.shadowBlur = 0
    
    ctx.fillStyle = '#8B4513'
    ctx.font = '24px Arial'
    ctx.fillText('杜青林成功登顶!', GAME_WIDTH / 2, GAME_HEIGHT / 2 + 20)
    
    const btnY = GAME_HEIGHT / 2 + 80
    ctx.fillStyle = '#4CAF50'
    ctx.fillRect(GAME_WIDTH / 2 - 60, btnY, 120, 40)
    ctx.fillStyle = '#FFF'
    ctx.font = 'bold 18px Arial'
    ctx.fillText('再玩一次', GAME_WIDTH / 2, btnY + 28)
  }, [])

  // Update game logic
  const updateGame = useCallback(() => {
    const state = gameStateRef.current
    if (!state.player || state.gameOver || state.gameWon) return
    
    const player = state.player
    const keys = state.keys
    
    // Handle movement
    if (keys['KeyA'] || keys['ArrowLeft']) {
      player.vx = -MOVE_SPEED
      player.facingRight = false
    } else if (keys['KeyD'] || keys['ArrowRight']) {
      player.vx = MOVE_SPEED
      player.facingRight = true
    } else {
      player.vx *= 0.8
    }
    
    // Apply gravity or rocket boost
    if (player.rocketActive) {
      player.vy = -10
    } else {
      player.vy += GRAVITY
    }
    
    // Apply velocity
    player.x += player.vx
    player.y += player.vy
    
    // Screen wrapping
    if (player.x < -player.width) player.x = GAME_WIDTH
    if (player.x > GAME_WIDTH) player.x = -player.width
    
    // Check platform collisions - use world coordinates
    // Sort platforms by layer (highest first) for correct collision
    const sortedPlatforms = [...state.platforms].sort((a, b) => b.layer - a.layer)
    
    for (const platform of sortedPlatforms) {
      // Check if player is falling and above platform
      if (player.vy > 0 &&
          player.x + player.width > platform.x &&
          player.x < platform.x + platform.width &&
          player.y + player.height >= platform.y &&
          player.y + player.height <= platform.y + PLATFORM_HEIGHT + player.vy) {
        
        // Land on platform
        player.y = platform.y - player.height
        player.vy = JUMP_FORCE
        
        // Create effects
        createRipple(player.x + player.width / 2, player.y + player.height)
        
        const sounds = [SOUND_FART, SOUND_LIGHTNING, SOUND_LAUGH, SOUND_BOING, SOUND_POP]
        playSound(sounds[Math.floor(Math.random() * sounds.length)])
        
        createParticles(player.x + player.width / 2, player.y + player.height, 'rgb(255, 215, 0)', 10)
        
        // Apply terrain effects
        if (!player.starActive) {
          if (platform.type === PLATFORM_WET) {
            player.vx *= 0.5
          } else if (platform.type === PLATFORM_SNOW) {
            player.vx *= 1.5
          }
        }
        
        // Update highest layer
        if (platform.layer > state.highestLayer) {
          state.highestLayer = platform.layer
          state.currentLayer = platform.layer
          
          // Generate more platforms ahead
          const topLayer = Math.max(...state.platforms.map(p => p.layer))
          for (let i = topLayer + 1; i <= topLayer + 10; i++) {
            generatePlatform(i)
          }
        }
        
        break // Only collide with one platform
      }
    }
    
    // Check item collisions
    const itemToCollect = state.items.find(item => 
      !item.collected &&
      player.x < item.x + 30 &&
      player.x + player.width > item.x &&
      player.y < item.y + 30 &&
      player.y + player.height > item.y
    )
    
    if (itemToCollect) {
      itemToCollect.collected = true
      playSound(SOUND_POP)
      createParticles(itemToCollect.x + 15, itemToCollect.y + 15, 'rgb(255, 255, 255)', 15)
      
      // Show power-up text
      state.powerUpText = {
        text: '杜青林牛逼!',
        timer: 120
      }
      
      if (itemToCollect.type === ITEM_ROCKET) {
        player.rocketActive = true
        player.rocketTime = 300
      } else if (itemToCollect.type === ITEM_STAR) {
        player.starActive = true
        player.starTime = 600
      } else if (itemToCollect.type === ITEM_MUSHROOM) {
        player.mushroomActive = true
        player.mushroomTime = 480
      }
    }
    
    // Update power-up timers
    if (player.rocketActive) {
      player.rocketTime--
      if (player.rocketTime <= 0) {
        player.rocketActive = false
        // Generate safety platform below player when rocket ends
        const safetyLayer = Math.floor(-player.y / LAYER_HEIGHT) + 2
        if (!state.generatedLayers.has(safetyLayer)) {
          state.platforms.push({
            x: Math.max(0, Math.min(GAME_WIDTH - 120, player.x - 40)),
            y: player.y + player.height + 50,
            width: 120,
            type: PLATFORM_NORMAL,
            layer: safetyLayer
          })
          state.generatedLayers.add(safetyLayer)
        }
      }
    }
    if (player.starActive) {
      player.starTime--
      if (player.starTime <= 0) player.starActive = false
    }
    if (player.mushroomActive) {
      player.mushroomTime--
      if (player.mushroomTime <= 0) player.mushroomActive = false
    }
    
    // Update power-up text timer
    if (state.powerUpText) {
      state.powerUpText.timer--
      if (state.powerUpText.timer <= 0) {
        state.powerUpText = null
      }
    }
    
    // Update camera - follow player smoothly
    // Camera Y is offset so player appears at 60% of screen height
    const targetCameraY = GAME_HEIGHT * 0.6 - (player.y + player.height)
    state.cameraY += (targetCameraY - state.cameraY) * 0.1
    
    // Remove platforms that are too far below (out of view)
    state.platforms = state.platforms.filter(p => p.y + state.cameraY < GAME_HEIGHT + 200)
    state.items = state.items.filter(i => !i.collected && i.y + state.cameraY < GAME_HEIGHT + 200)
    
    // Check win condition
    if (state.highestLayer >= MAX_LAYERS) {
      state.gameWon = true
      setGameState(prev => ({ ...prev, gameWon: true }))
    }
    
    // Check lose condition - player fell below visible area
    if (player.y + state.cameraY > GAME_HEIGHT + 100) {
      state.gameOver = true
      setGameState(prev => ({ ...prev, gameOver: true }))
    }
    
    // Update UI
    setGameState(prev => ({ ...prev, layer: state.highestLayer }))
  }, [createRipple, createParticles, generatePlatform, playSound])

  // Initialize game
  const initGame = useCallback(() => {
    const state = gameStateRef.current
    
    // Reset state
    // Ground platform will be at y: 0
    // Player needs to stand ON the platform, so player.y (top of player) = -PLAYER_HEIGHT
    state.player = {
      x: GAME_WIDTH / 2 - PLAYER_WIDTH / 2,
      y: -PLAYER_HEIGHT,  // Player top at -60, feet at y=0 (on ground platform)
      vx: 0,
      vy: 0,
      width: PLAYER_WIDTH,
      height: PLAYER_HEIGHT,
      rocketActive: false,
      rocketTime: 0,
      starActive: false,
      starTime: 0,
      mushroomActive: false,
      mushroomTime: 0,
      facingRight: true
    }

    state.platforms = []
    state.items = []
    // Camera Y: screenY = worldY + cameraY
    // Player feet at worldY=0, we want them at screenY = GAME_HEIGHT * 0.6
    // So cameraY = GAME_HEIGHT * 0.6 - (player.y + player.height) = 432 - 0 = 432
    state.cameraY = GAME_HEIGHT * 0.6
    state.currentLayer = 0
    state.highestLayer = 0
    state.gameOver = false
    state.gameWon = false
    state.gameStarted = true
    state.ripples = []
    state.particles = []
    state.powerUpText = null
    state.generatedLayers = new Set()
    
    // Generate ground platform (layer 0)
    generatePlatform(0)
    
    // Override ground platform to be full width
    state.platforms[0] = {
      x: 0,
      y: 0,
      width: GAME_WIDTH,
      type: PLATFORM_NORMAL,
      layer: 0
    }
    state.generatedLayers.add(0)
    
    // Generate initial platforms
    for (let i = 1; i <= 15; i++) {
      generatePlatform(i)
    }
    
    setGameState({
      started: true,
      gameOver: false,
      gameWon: false,
      layer: 0
    })
    
    startBGM()
  }, [generatePlatform, startBGM])

  // Start game loop
  useEffect(() => {
    const gameLoop = (timestamp: number) => {
      const canvas = canvasRef.current
      if (!canvas) {
        animationRef.current = requestAnimationFrame(gameLoop)
        return
      }
      
      const ctx = canvas.getContext('2d')
      if (!ctx) {
        animationRef.current = requestAnimationFrame(gameLoop)
        return
      }
      
      const state = gameStateRef.current
      
      state.deltaTime = timestamp - state.lastTime
      state.lastTime = timestamp
      state.frameCount++
      
      ctx.clearRect(0, 0, GAME_WIDTH, GAME_HEIGHT)
      
      if (!state.gameStarted) {
        drawStartScreen(ctx)
      } else if (state.gameOver) {
        drawGameOverScreen(ctx)
      } else if (state.gameWon) {
        drawWinScreen(ctx)
      } else {
        updateGame()
        
        drawBackground(ctx)
        
        // Draw platforms (sorted by layer for correct z-order)
        const sortedPlatforms = [...state.platforms].sort((a, b) => a.layer - b.layer)
        sortedPlatforms.forEach(platform => {
          drawPlatform(ctx, platform, state.cameraY)
        })
        
        // Draw items
        state.items.forEach(item => {
          drawItem(ctx, item, state.cameraY, state.frameCount)
        })
        
        drawRipples(ctx, state.cameraY)
        drawParticles(ctx, state.cameraY)
        
        if (state.player) {
          drawPlayer(ctx, state.player, state.cameraY, state.frameCount)
        }
        
        drawHUD(ctx, state.highestLayer)
      }
      
      animationRef.current = requestAnimationFrame(gameLoop)
    }
    
    animationRef.current = requestAnimationFrame(gameLoop)
    
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [updateGame, drawBackground, drawPlatform, drawItem, drawPlayer, drawRipples, drawParticles, drawHUD, drawStartScreen, drawGameOverScreen, drawWinScreen])

  // Handle keyboard input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      gameStateRef.current.keys[e.code] = true
      
      if (!gameStateRef.current.gameStarted) {
        initGame()
      }
    }
    
    const handleKeyUp = (e: KeyboardEvent) => {
      gameStateRef.current.keys[e.code] = false
    }
    
    window.addEventListener('keydown', handleKeyDown)
    window.addEventListener('keyup', handleKeyUp)
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown)
      window.removeEventListener('keyup', handleKeyUp)
    }
  }, [initGame])

  // Handle touch input for mobile
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    
    let touchStartX = 0
    
    const handleTouchStart = (e: TouchEvent) => {
      const touch = e.touches[0]
      touchStartX = touch.clientX
      
      if (!gameStateRef.current.gameStarted) {
        initGame()
        return
      }
      
      if (gameStateRef.current.gameOver || gameStateRef.current.gameWon) {
        const rect = canvas.getBoundingClientRect()
        const y = touch.clientY - rect.top
        const btnY = GAME_HEIGHT / 2 + 80
        
        if (y >= btnY && y <= btnY + 40) {
          initGame()
        }
      }
    }
    
    const handleTouchMove = (e: TouchEvent) => {
      if (!gameStateRef.current.gameStarted || gameStateRef.current.gameOver || gameStateRef.current.gameWon) return
      
      const touch = e.touches[0]
      const diff = touch.clientX - touchStartX
      
      if (diff < -20) {
        gameStateRef.current.keys['ArrowLeft'] = true
        gameStateRef.current.keys['ArrowRight'] = false
      } else if (diff > 20) {
        gameStateRef.current.keys['ArrowRight'] = true
        gameStateRef.current.keys['ArrowLeft'] = false
      } else {
        gameStateRef.current.keys['ArrowLeft'] = false
        gameStateRef.current.keys['ArrowRight'] = false
      }
    }
    
    const handleTouchEnd = () => {
      gameStateRef.current.keys['ArrowLeft'] = false
      gameStateRef.current.keys['ArrowRight'] = false
    }
    
    canvas.addEventListener('touchstart', handleTouchStart)
    canvas.addEventListener('touchmove', handleTouchMove)
    canvas.addEventListener('touchend', handleTouchEnd)
    
    return () => {
      canvas.removeEventListener('touchstart', handleTouchStart)
      canvas.removeEventListener('touchmove', handleTouchMove)
      canvas.removeEventListener('touchend', handleTouchEnd)
    }
  }, [initGame])

  // Handle mouse click for buttons
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    
    const handleClick = (e: MouseEvent) => {
      if (!gameStateRef.current.gameStarted) {
        initGame()
        return
      }
      
      const rect = canvas.getBoundingClientRect()
      const y = e.clientY - rect.top
      
      if (gameStateRef.current.gameOver || gameStateRef.current.gameWon) {
        const btnY = GAME_HEIGHT / 2 + 80
        const btnX = GAME_WIDTH / 2 - 60
        
        if (y >= btnY && y <= btnY + 40 && 
            e.clientX - rect.left >= btnX && e.clientX - rect.left <= btnX + 120) {
          initGame()
        }
      }
    }
    
    canvas.addEventListener('click', handleClick)
    
    return () => {
      canvas.removeEventListener('click', handleClick)
    }
  }, [initGame])

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900">
      <div className="relative">
        <canvas
          ref={canvasRef}
          width={GAME_WIDTH}
          height={GAME_HEIGHT}
          className="border-4 border-yellow-400 rounded-lg shadow-2xl"
          style={{
            maxWidth: '100vw',
            maxHeight: '100vh',
            touchAction: 'none'
          }}
        />
      </div>
    </div>
  )
}
